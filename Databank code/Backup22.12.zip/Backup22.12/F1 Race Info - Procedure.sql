----------------------------------------------------------------------
--                         Formula 1 
----------------------------------------------------------------------

----------------------------------------------------------------------
-- Stored Procedure - Race Info
----------------------------------------------------------------------
USE Formula1
GO

DROP PROCEDURE IF EXISTS RaceInfo
GO

CREATE PROCEDURE RaceInfo(@RaceID INT)
AS BEGIN
    DECLARE @Info VARCHAR(MAX);

    IF EXISTS (SELECT 1 FROM Race WHERE @RaceID = RaceID) 
    BEGIN
        SELECT @Info = 'The ' + CAST(R.RaceID AS VARCHAR) + ' race of the 2023 Season unfolded on ' + CAST(R.RaceDate AS VARCHAR) + 
            ', at the picturesque ' + R.RaceLocation + ' in ' + R.Country + '. The spotlight was on the much-anticipated ' + CHAR(13) + CHAR(10) +  
            R.RaceName + ', held on the challenging ' + R.CircuitName + '. This renowned circuit stretches across a substantial ' + 
            CAST(R.CircuitLengthKM AS VARCHAR)  + ' kilometers, with each race covering an impressive distance of ' + CAST(R.RaceDistanceKM AS VARCHAR)  + '.'  + CHAR(13) + CHAR(10) +  
            'Distinguished by its ' + CAST(R.NumberOfLaps AS VARCHAR) + ' laps and strategically placed ' + CAST(R.NumberOfCorners  AS VARCHAR) + ' corners the ' + 
            R.CircuitName + ' has become a cornerstone in the world of racing. Since its inception in ' + CAST(R.YearOf1GP AS VARCHAR)  + CHAR(13) + CHAR(10) +  
            ', it has hosted exhilarating races, attracting both seasoned drivers and avid fans.' + 
            CASE 
                WHEN FP.fk_DriverID IS NOT NULL THEN 'As the 2023 race unfolded on the famed ' + R.CircuitName + 
                    ', the competition was fierce. Notably, ' + CAST(FP.fk_DriverID AS VARCHAR) + ' displayed a remarkable performance, securing 
					an impressive First Place and earning ' + CAST(FP.Points AS VARCHAR) + ' points. Following closely behind, '  + CHAR(13) + CHAR(10) +  
                    CAST(SP.fk_DriverID AS VARCHAR) + ' claimed the second position, accruing ' + CAST(SP.Points AS VARCHAR) + ' points. The podium was completed 
                    with a commendable third-place finish by ' + CAST(TP.fk_DriverID AS VARCHAR) + ', who garnered ' + CAST(TP.Points AS VARCHAR) + ' points.'  + CHAR(13) + CHAR(10)
                WHEN FP.fk_DriverID IS NULL THEN 'The race faced a disappointing cancellation due to severe and unprecedented 
                    weather conditions. The decision prioritized the safety of participants and spectators, acknowledging the'  + CHAR(13) + CHAR(10) +  
                    'challenges posed by extreme precipitation and high winds. Despite the disappointment, the organizers are hopeful 
                    for an entertaining race next season.'
            END + 
            'This event marked another thrilling chapter in the storied history of races at ' + R.CircuitName + ', showcasing the 
            skill and determination of the participants. The legacy of this' + CHAR(13) + CHAR(10) +  'iconic circuit continues to unfold, providing racing 
            enthusiasts with unforgettable moments on the track.'
        FROM Race R 
        JOIN FirstPlace FP ON R.RaceID = FP.fk_RaceID
        JOIN SecondPlace SP ON R.RaceID = SP.fk_RaceID
        JOIN ThirdPlace TP ON R.RaceID = TP.fk_RaceID
        WHERE @RaceID = R.RaceID;  -- Fixed the table alias for RaceID

    END
    ELSE
    BEGIN
        SET @Info = 'Race not found.';
        PRINT @Info;
    END
	PRINT @Info;
END
GO

-- Example usage
EXEC RaceInfo 7;
